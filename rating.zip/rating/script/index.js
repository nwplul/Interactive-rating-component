const submit_button = document.getElementById("submit-button")


function submit() {
    window.location.href = ""
}